package com.example.avtopark

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView

class Search_admin : AppCompatActivity() {
    private lateinit var recucle: RecyclerView
    private lateinit var databaseHelper: DBHelper//
    private var userAdapter: AdminAdapter? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_admin)
        databaseHelper = DBHelper(this)

        // Find and initialize the BackButton from fragmentLayout
        val BackButton: ImageButton = findViewById(R.id.ButtonBackAdmin)
        BackButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Find and initialize recucle from fragmentLayout
        recucle = findViewById(R.id.recycle_admin)

        // Call the printList function with recucle
        printList(recucle)
    }
    fun printList(recucle: RecyclerView) {
        val userList: MutableList<Driver> = databaseHelper.getAllDriversData().toMutableList()
        if (userList.isNotEmpty()) {
            recucle.layoutManager = LinearLayoutManager(this)

            recucle.adapter = userAdapter
        } else {
            Toast.makeText(this, "No routes found", Toast.LENGTH_SHORT).show()
        }

        // Создаем и устанавливаем менеджер компоновки для RecyclerView
        recucle.layoutManager = LinearLayoutManager(this)

        // Создаем экземпляр адаптера и устанавливаем его для RecyclerView
        userAdapter = AdminAdapter(userList,
            onDeleteClickListener = { deletedUser ->
                // Вызываем метод для удаления
                databaseHelper.deleteDriverData(deletedUser.id)
                printList(recucle)
            },
            onEditClickListener = { editedUser ->
                var user: Array<String> = arrayOf(
                    editedUser.id.toString(), editedUser.FIO, editedUser.price.toString(), editedUser.premia.toString(),editedUser.sity
                )

                val builder = android.app.AlertDialog.Builder(this)
                builder.setTitle("Введите данные")

                // Создайте контейнер LinearLayout для размещения двух EditText
                val layout = LinearLayout(this)
                layout.orientation = LinearLayout.VERTICAL

                val EditId = EditText(this)
                val EditFIO = EditText(this)
                val EditPrice = EditText(this)
                val EditPremia= EditText(this)
                val EditSity= EditText(this)

                EditId.hint = "Введите id"
                EditFIO.hint = "Введите фамилию"
                EditPrice.hint = "Введите зарплату"
                EditPremia.hint="Введите премию"
                EditSity.hint="Введите город"

                EditId.setText(user[0])
                EditFIO.setText(user[1])
                EditPrice.setText(user[2])
                EditPremia.setText(user[3])
                EditSity.setText(user[4])


                layout.addView(EditId)
                layout.addView(EditFIO)
                layout.addView(EditPrice)
                layout.addView(EditPremia)
                layout.addView(EditSity)

                builder.setView(layout)

                builder.setPositiveButton("OK") { dialog, _ ->
                    var Id = EditId.text.toString()
                    var FIO = EditFIO.text.toString()
                    var Price = EditPrice.text.toString()
                    var Premia = EditPremia.text.toString()
                    var Sity = EditSity.text.toString()
                    if(Id.isEmpty()){
                        Id=user[0]
                    }
                    if (FIO.isEmpty()) {
                        FIO = user[1];
                    }
                    if (Price.isEmpty()) {
                        Price = user[2];
                    }
                    if (Premia.isEmpty()) {
                        Premia = user[3];
                    }
                    if (Sity.isEmpty()) {
                        Sity = user[4];
                    }
                    //изменения в бд
                    databaseHelper.updateDriverData(Id.toLong(), FIO, Price.toInt(), Premia.toInt(), Sity)
                    //обновление листа
                    printList(recucle)
                }

                builder.setNegativeButton("Отмена") { dialog, _ ->
                    dialog.cancel()
                }

                val dialog = builder.create()
                dialog.show()

            }
        )
        recucle.adapter = userAdapter
    }

    fun addButClick(view: View) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Введите данные")

        // Создайте контейнер LinearLayout для размещения двух EditText
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val EditId = EditText(this)
        val EditFIO = EditText(this)
        val EditPrice = EditText(this)
        val EditPremia= EditText(this)
        val EditSity= EditText(this)

        EditId.hint = "Введите id"
        EditFIO.hint = "Введите фамилию"
        EditPrice.hint = "Введите зарплату"
        EditPremia.hint="Введите премию"
        EditSity.hint="Введите город"

        // Добавьте EditText к контейнеру
        layout.addView(EditId)
        layout.addView(EditFIO)
        layout.addView(EditPrice)
        layout.addView(EditPremia)
        layout.addView(EditSity)

        builder.setView(layout)

        // Установите кнопку "OK" для сохранения данных
        builder.setPositiveButton("OK") { dialog, _ ->
            var Id = EditId.text.toString()
            var FIO = EditFIO.text.toString()
            var Price = EditPrice.text.toString()
            var Premia = EditPremia.text.toString()
            var Sity = EditSity.text.toString()
            // Здесь можно обработать введенные данные (value1 и value2)
            //запись в бд
            if(Id.isEmpty() || FIO.isEmpty() || Price.isEmpty() || Premia.isEmpty()||Sity.isEmpty()){
                val builder = android.app.AlertDialog.Builder(this)
                builder.setTitle("Не сохранено")
                    .setMessage("Необходимо заполнить все поля")
                    .setPositiveButton("ОК") {
                            dialog, id ->  dialog.cancel()
                    }
                builder.create()
            }
            else{
                //сама запись
                databaseHelper.addDriverData(Id.toLong(),FIO,Price.toInt(),Premia.toInt(),Sity )
                printList(recucle)
            }

        }

        builder.setNegativeButton("Отмена") { dialog, _ ->
            dialog.cancel()
        }

        val dialog = builder.create()
        dialog.show()
    }
}