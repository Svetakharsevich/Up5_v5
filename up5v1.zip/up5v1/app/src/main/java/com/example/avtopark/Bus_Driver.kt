package com.example.avtopark

data class Bus_Driver(val id_bus:Long, val driver:String)