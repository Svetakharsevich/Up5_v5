package com.example.avtopark

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Driver_rab.newInstance] factory method to
 * create an instance of this fragment.
 */
class Driver_rab : Fragment() {
    private lateinit var dbHelper: DBHelper
    private var driverId: Long = -1
    private lateinit var listView: ListView
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)

        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val fragmentLayout = inflater.inflate(R.layout.fragment_driver_rab, container, false)
        dbHelper = DBHelper(requireContext())
        driverId = dbHelper.getDriverIdFromSharedPreferences(requireContext()).toLong()

        val textViewInfo = fragmentLayout.findViewById<TextView>(R.id.textViewDriverInfo)

        val routeDriverInfo = dbHelper.getRoutesDriverInfoById(driverId)
        val driverInfo = dbHelper.getDriverInfoById(driverId)

        if (routeDriverInfo != null && driverInfo != null) {
            // Объедините информацию о маршруте водителя и водителе в одну строку
            val fullInfo = """
    Маршрут: ${routeDriverInfo.id}
    Время работы: ${routeDriverInfo.time}
    Состояние автобуса: ${routeDriverInfo.condition}
    Процент амортизации автобуса: ${routeDriverInfo.percent}
    Модель автобуса: ${routeDriverInfo.model}
    
    Идентификатор водителя: ${driverInfo.id}
    Фамилия: ${driverInfo.FIO}
    Зарплата: ${driverInfo.price}
    Дополнительная премия: ${driverInfo.premia}
""".trimIndent()

            // Установите объединенную информацию в TextView
            textViewInfo.text = fullInfo
        }

        return fragmentLayout
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Driver_rab.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: DBHelper, param2: String) =
            Driver_rab().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1.toString())
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}