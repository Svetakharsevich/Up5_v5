package com.example.avtopark

import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView

class AdminViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    val ID_admin:TextView=itemView.findViewById(R.id.ID_driver_admin)
    val FIO:TextView=itemView.findViewById(R.id.FIO_admin)
    val Price:TextView=itemView.findViewById(R.id.price_admin)
    val Premia:TextView=itemView.findViewById(R.id.premia_admin)
    val Sity_admin:TextView=itemView.findViewById(R.id.sity_admin)
    val editButton: AppCompatButton = itemView.findViewById(R.id.editBut)
    val deleteBut: AppCompatButton = itemView.findViewById(R.id.deleteBut)
}