package com.example.avtopark

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class items_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items_admin)
    }
}