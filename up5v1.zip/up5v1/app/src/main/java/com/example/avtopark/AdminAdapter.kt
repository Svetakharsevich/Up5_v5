package com.example.avtopark

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class AdminAdapter(  var rabList: MutableList<Driver> = mutableListOf(),
                     private val onDeleteClickListener: (Driver) -> Unit,
                     private val onEditClickListener: (Driver) -> Unit) : RecyclerView.Adapter<AdminViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_items_admin, parent, false)
        return AdminViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AdminViewHolder, position: Int) {
        val currentUser = rabList[position]

        holder.ID_admin.text = "Id Водителя: ${currentUser.id}"

        holder.FIO.text = "Фамилия водителя: ${currentUser.FIO}"

        holder.Price.text = "Процент амортизации: ${currentUser.price}"

        holder.Premia.text = "Модель автобуса: ${currentUser.premia}"

        holder.Sity_admin.text="Город: ${currentUser.sity}"

        holder.editButton.setOnClickListener {
            onEditClickListener(currentUser)
        }

        // Обработчик события для кнопки удаления
        holder.deleteBut.setOnClickListener {
            onDeleteClickListener(currentUser)
        }
    }

    override fun getItemCount(): Int {
        return rabList.size
    }

    fun updateData(newDataList: MutableList<Driver>) {
        rabList.clear()
        rabList.addAll(newDataList)
        notifyDataSetChanged()
    }
}