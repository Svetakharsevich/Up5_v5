package com.example.avtopark

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.navigation.NavigationView

class Search_rab : AppCompatActivity() {
    private lateinit var dbHelper: DBHelper
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_rab)
        dbHelper = DBHelper(this)
        val host: NavHostFragment = supportFragmentManager.findFragmentById(R.id.navFragment) as NavHostFragment? ?: return
        val navController = host.navController
       // supportFragmentManager.beginTransaction().replace(R.id.driver_rab, fragment).commit()

        val sideBar = findViewById<NavigationView>(R.id.nav_view)
        sideBar?.setupWithNavController(navController)
        sideBar.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.Home_rab -> {
                    navController.navigate(R.id.searchFragment)
                    true
                }

                R.id.search_rab -> {
                    navController.navigate(R.id.info_rab)
                    true
                }
                R.id.Drivers -> {
                    navController.navigate(R.id.driver_rab)
                    true
                }
                else -> false
            }
        }
    }
}