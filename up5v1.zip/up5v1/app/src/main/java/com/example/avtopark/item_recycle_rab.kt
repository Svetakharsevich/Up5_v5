package com.example.avtopark

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class item_recycle_rab : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_recycle_rab)
    }
}