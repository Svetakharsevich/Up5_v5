package com.example.avtopark

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ItemRecycle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_recycle)
    }
}