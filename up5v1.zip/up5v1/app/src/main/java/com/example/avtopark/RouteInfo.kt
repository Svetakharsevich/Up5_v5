package com.example.avtopark

import java.sql.Date

data class RouteInfo(val id:String, val driver:Long, val time:String)