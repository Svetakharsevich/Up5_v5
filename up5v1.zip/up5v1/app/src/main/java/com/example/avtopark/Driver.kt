package com.example.avtopark

data class Driver(val id:Long, val FIO:String, val price:Int, val premia:Int,val sity:String)
