package com.example.avtopark

data class BusInfo( val id: Long,
                    val driverId: Long)