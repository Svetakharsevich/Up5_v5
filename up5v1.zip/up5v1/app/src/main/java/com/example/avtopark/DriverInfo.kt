package com.example.avtopark

data class DriverInfo(
    val id: String,
    val driver: String, val time:String, val condition:String, val percent: Int, val model:String)