package com.example.avtopark

data class RoutesDriver(val routes:String, val driver:String,val time:String)