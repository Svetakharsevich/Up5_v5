package com.example.avtopark

data class BusRouteItem(
    var idBus: Long,
    val idRoutes: String,
    val idBusDriver: Long,
    val idDriverBus: String
)