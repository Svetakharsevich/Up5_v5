package com.example.avtopark

data class Bus(val id:Long, val condition:String, val percent: Int, val model:String)