package com.example.avtopark

data class Routes(val id:Long,val stoping:String,val sity_routes:String)