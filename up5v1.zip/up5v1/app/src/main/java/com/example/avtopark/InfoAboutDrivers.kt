package com.example.avtopark

data class InfoAboutDrivers(val id:Int,val email:String,val login:String,val password:String)